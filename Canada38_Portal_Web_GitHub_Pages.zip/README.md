# 🍁 CANADÁ ÁREA DE RISCO 38 • PORTAL OFICIAL DE REGRAS

Portal interativo e tático de regras, cotas de baú, diretrizes da facção e doutrina tática para o servidor **Valley Roleplay**.

---

## 🚀 Como publicar no GitHub Pages (Gratuito em 2 minutos):

1. Crie um novo repositório no seu GitHub com o nome que desejar (ex: `canada-regras`).
2. Faça o upload do arquivo `index.html` (e dos arquivos desta pasta).
3. No seu repositório no GitHub, clique em **Settings** (Configurações).
4. No menu lateral esquerdo, clique em **Pages**.
5. Em **Branch**, selecione `main` (ou `master`) e a pasta `/(root)`.
6. Clique em **Save**.
7. Pronto! Em poucos segundos o GitHub fornecerá o link público do seu portal:  
   `https://seu-usuario.github.io/canada-regras/`
